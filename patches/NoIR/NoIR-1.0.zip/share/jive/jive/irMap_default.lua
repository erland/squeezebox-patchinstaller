-- IR button name to IR code for all Logitech "Squeezebox family" remote controls
irMap = {}
irMap["name"] = "No IR Remote" 
irMap["map"] = {
}
